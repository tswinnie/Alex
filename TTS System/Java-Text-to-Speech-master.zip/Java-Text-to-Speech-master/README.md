Java-Text-to-Speech
===================

Application Text to Speech With Java Programming Using FreeTTS Library