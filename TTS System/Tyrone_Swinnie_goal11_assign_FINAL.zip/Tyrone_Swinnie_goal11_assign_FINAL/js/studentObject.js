/*Tyrone Swinnie
Final Exam
*/
(function (){

var number = 0;
// Array of students
var students = [
		// creating student objects using the constructor
		new Student("Matthew Stafford", "100 University BLv, Athens, GA", [2.5, 4.0, 2.2], getDate()),
		new Student("Tyrone Swinnie", "103 Peachtress st. Americus, GA", [4.5, 4.0, 3.2], getDate())
];

    //this is for accessing the dom classes and ids
var dom = {
	btn:document.querySelector(".buttonred"),
	name:document.querySelector("#name"),
	address:document.querySelector("#address"),
	gpa:document.querySelector("#gpa"),
	date:document.querySelector("#date"),
	gpaavg:document.querySelector("#gpaavg")
};



function Student(n,a,g,d){
	this.name = n;
	this.address = a;
	this.gpa = g;
	this.date = d;
}

// console.log the original array
console.log("#####This is the array of students BEFORE#####");
display();

// added a new object (using a constructor) to the array of student objects above
var newStudent = new Student("Nick Cannon", "989 East st, Orlando Florida", [2.0, 3.0, 4.2], getDate());
students.push(newStudent);

// console.log after student was added to array
console.log("#####This is the array of students AFTER#####");
display();

// Add an event listener for the button
dom.btn.addEventListener("click", onClick, false); 

// ########################### FUNCTIONS ###########################

// Function that will display the first student of the array
function beginning(){
	dom.name.innerHTML = "Name: " + students[number].name;
	dom.address.innerHTML = "Address: " + students[number].address;
	dom.gpa.innerHTML = "GPA: " + students[number].gpa;
	dom.date.innerHTML = "Date: " + getDate();
	dom.gpaavg.innerHTML = "Average GPA: " + students[number].getAvg();
}

// For loop to display students in the console.log
function display (){
	for (var an=0; an < students.length ;an++) {
	
	console.log("###  This is student " + (an +1) + " ###");
	for (var prop in students[an]){
		console.log(prop + " " + students[an][prop]);
		};
	console.log("                           ");
	}
}

// Function that will run once we click on the button
function onClick(){
		number++;
		dom.name.innerHTML = "Name: " + students[number].name;
		dom.address.innerHTML = "Address: " + students[number].address;
		dom.gpa.innerHTML = "GPA: " + students[number].gpa;
		dom.date.innerHTML = "Date: " + getDate();
		dom.gpaavg.innerHTML = "Average GPA: " + students[number].getAvg();
		full();
};


// Function to check if we clicked through the whole array
function full(){
	if (number == students.length - 1) {
		document.querySelector(".buttonred").innerHTML = "Done!!!";
		dom.btn.removeEventListener("click", onClick, false);
	}
}

// Function to get the date
function getDate (){
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1;

	var yyyy = today.getFullYear();
	if(dd<10){
		dd='0'+ dd;
	} 
	if(mm<10){
		mm='0'+ mm;
	} 
	today = mm+'/'+dd+'/'+yyyy;
	return today;
}

Student.prototype.getAvg = function(){
	var n = this.gpa;
	var total =0;

	n.forEach(function(e){
		total += e;
	})

	var avg = total / n.length;
	var result=Math.round(avg*100)/100;
	return result;
	
}

// ########################### Functions Calls ###########################

beginning(); // Display 1st student

})();
